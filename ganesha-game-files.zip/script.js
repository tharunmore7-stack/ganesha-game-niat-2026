const loginScreen = document.getElementById("loginScreen");
const gameScreen = document.getElementById("gameScreen");
const resultScreen = document.getElementById("resultScreen");

const playerNameInput = document.getElementById("playerName");
const niatIdInput = document.getElementById("niatId");
const loginError = document.getElementById("loginError");

const startBtn = document.getElementById("startBtn");
const restartBtn = document.getElementById("restartBtn");
const playAgainBtn = document.getElementById("playAgainBtn");
const homeBtn = document.getElementById("homeBtn");

const gameArea = document.getElementById("gameArea");
const scoreEl = document.getElementById("score");
const timeEl = document.getElementById("time");
const displayName = document.getElementById("displayName");
const finalScore = document.getElementById("finalScore");
const resultText = document.getElementById("resultText");
const message = document.getElementById("message");

let score = 0;
let timeLeft = 45;
let timer = null;
let playerName = "";

function showScreen(screen) {
  [loginScreen, gameScreen, resultScreen].forEach(s => s.classList.remove("active"));
  screen.classList.add("active");
}

function validateLogin() {
  const name = playerNameInput.value.trim();
  const id = niatIdInput.value.trim();

  if (!name) {
    loginError.textContent = "Please enter your name.";
    playerNameInput.focus();
    return false;
  }

  if (!id) {
    loginError.textContent = "Please enter your NIAT ID.";
    niatIdInput.focus();
    return false;
  }

  loginError.textContent = "";
  playerName = name;
  return true;
}

function startGame() {
  if (!validateLogin()) return;

  displayName.textContent = playerName;
  showScreen(gameScreen);
  resetGame();
}

function resetGame() {
  clearInterval(timer);
  score = 0;
  timeLeft = 45;
  scoreEl.textContent = score;
  timeEl.textContent = timeLeft;
  message.textContent = "Collect the modaks!";
  removeModaks();

  // Give the player a moment to see the game before spawning.
  spawnModak();
  spawnModak();
  spawnModak();

  timer = setInterval(() => {
    timeLeft--;
    timeEl.textContent = timeLeft;

    if (timeLeft <= 0) {
      endGame();
    }
  }, 1000);
}

function removeModaks() {
  document.querySelectorAll(".modak").forEach(item => item.remove());
}

function spawnModak() {
  const modak = document.createElement("button");
  modak.className = "modak";
  modak.type = "button";
  modak.textContent = "🍡";
  modak.setAttribute("aria-label", "Collect modak");

  const areaRect = gameArea.getBoundingClientRect();
  const maxX = Math.max(70, areaRect.width - 100);
  const maxY = Math.max(120, areaRect.height - 150);

  modak.style.left = `${20 + Math.random() * (maxX - 20)}px`;
  modak.style.top = `${35 + Math.random() * (maxY - 35)}px`;

  modak.addEventListener("click", () => {
    score++;
    scoreEl.textContent = score;
    modak.remove();
    spawnModak();

    if (score % 5 === 0) {
      message.textContent = `Amazing, ${playerName}! 🎉`;
      setTimeout(() => {
        if (timeLeft > 0) message.textContent = "Keep collecting!";
      }, 900);
    }
  });

  gameArea.appendChild(modak);
}

function endGame() {
  clearInterval(timer);
  removeModaks();

  finalScore.textContent = score;
  resultText.textContent =
    `Well played, ${playerName}! You collected ${score} modak${score === 1 ? "" : "s"} in 45 seconds.`;

  showScreen(resultScreen);
}

startBtn.addEventListener("click", startGame);
restartBtn.addEventListener("click", resetGame);
playAgainBtn.addEventListener("click", () => {
  showScreen(gameScreen);
  resetGame();
});

homeBtn.addEventListener("click", () => {
  clearInterval(timer);
  showScreen(loginScreen);
  loginError.textContent = "";
});

[playerNameInput, niatIdInput].forEach(input => {
  input.addEventListener("keydown", event => {
    if (event.key === "Enter") startGame();
  });
});

// Keep the game playable if the browser is resized.
window.addEventListener("resize", () => {
  document.querySelectorAll(".modak").forEach(item => item.remove());
  if (gameScreen.classList.contains("active") && timeLeft > 0) {
    spawnModak();
    spawnModak();
    spawnModak();
  }
});
